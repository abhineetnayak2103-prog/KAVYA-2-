from __future__ import annotations
from datetime import datetime, timezone
import discord
from discord import app_commands
from discord.ext import commands

import config
from utils import embeds
from utils.ownership import is_bot_owner, is_main_owner, main_owner_only, bot_owner_only

CATEGORY = "Owner"


class Owner(commands.Cog):
    """Permanent Main Owner, secondary bot owners, no-prefix access & server control."""
    category = CATEGORY

    def __init__(self, bot: commands.Bot):
        self.bot = bot

    async def _audit(self, ctx: commands.Context, action: str, detail: str = ""):
        if ctx.guild:
            await self.bot.db.log_owner_action(ctx.guild.id, ctx.author.id, action, detail)

    # ============================================================
    #  👑  owner  — permanent Main Owner + secondary bot owners
    # ============================================================
    @commands.hybrid_group(
        name="owner",
        description="View or manage Kavya's bot owners.",
        invoke_without_command=True,
    )
    async def owner(self, ctx: commands.Context):
        main = self.bot.get_user(config.MAIN_OWNER_ID)
        rows = await self.bot.db.fetchall("SELECT user_id FROM bot_owners ORDER BY added_at ASC")

        embed = embeds.plain(title="👑 Kavya — Ownership Panel")
        embed.add_field(
            name="Main Owner  •  permanent",
            value=f"👑 {main.mention if main else f'`{config.MAIN_OWNER_ID}`'}",
            inline=False,
        )
        secondary = "\n".join(f"⭐ <@{r['user_id']}>" for r in rows) or "*No secondary owners added yet.*"
        embed.add_field(name=f"Secondary Owners ({len(rows)})", value=secondary, inline=False)
        embed.add_field(
            name="Subcommands",
            value="`owner add` `owner remove` `owner list` `owner lockdown` `owner unlock` "
                  "`owner slowmodeall` `owner emergency` `owner permissions` `owner audit`",
            inline=False,
        )
        await ctx.send(embed=embed)

    @owner.command(name="add", description="Add a secondary bot owner. Main Owner only.")
    @app_commands.describe(user="The user to grant owner access to")
    @main_owner_only()
    async def owner_add(self, ctx: commands.Context, user: discord.User):
        if user.id == config.MAIN_OWNER_ID:
            return await ctx.send(embed=embeds.info(f"{user.mention} is already the permanent Main Owner."))
        if await is_bot_owner(self.bot, user.id):
            return await ctx.send(embed=embeds.warning(f"{user.mention} is already a secondary owner."))
        await self.bot.db.execute(
            "INSERT INTO bot_owners (user_id, added_by, added_at) VALUES (?, ?, ?)",
            (user.id, ctx.author.id, int(datetime.now(timezone.utc).timestamp())),
        )
        await self._audit(ctx, "owner_add", str(user.id))
        await ctx.send(embed=embeds.success(f"⭐ {user.mention} is now a secondary bot owner."))

    @owner.command(name="remove", description="Remove a secondary bot owner. Main Owner only.")
    @app_commands.describe(user="The user to remove owner access from")
    @main_owner_only()
    async def owner_remove(self, ctx: commands.Context, user: discord.User):
        if user.id == config.MAIN_OWNER_ID:
            return await ctx.send(embed=embeds.error("The permanent Main Owner cannot be removed."))
        await self.bot.db.execute("DELETE FROM bot_owners WHERE user_id = ?", (user.id,))
        await self._audit(ctx, "owner_remove", str(user.id))
        await ctx.send(embed=embeds.success(f"Removed {user.mention} from secondary owners."))

    @owner.command(name="list", description="List the permanent Main Owner and all secondary owners.")
    async def owner_list(self, ctx: commands.Context):
        await self.owner(ctx)

    # ---------- server control (any bot owner) ----------
    @owner.command(name="lockdown", description="Lock every text channel in this server.")
    @bot_owner_only()
    @commands.guild_only()
    async def owner_lockdown(self, ctx: commands.Context):
        await ctx.defer() if ctx.interaction else None
        for channel in ctx.guild.text_channels:
            try:
                overwrite = channel.overwrites_for(ctx.guild.default_role)
                overwrite.send_messages = False
                await channel.set_permissions(ctx.guild.default_role, overwrite=overwrite)
            except discord.Forbidden:
                continue
        await self._audit(ctx, "lockdown")
        await ctx.send(embed=embeds.error("🔒 The entire server has been locked down.", title="Server Lockdown"))

    @owner.command(name="unlock", description="Unlock every text channel in this server.")
    @bot_owner_only()
    @commands.guild_only()
    async def owner_unlock(self, ctx: commands.Context):
        await ctx.defer() if ctx.interaction else None
        for channel in ctx.guild.text_channels:
            try:
                overwrite = channel.overwrites_for(ctx.guild.default_role)
                overwrite.send_messages = None
                await channel.set_permissions(ctx.guild.default_role, overwrite=overwrite)
            except discord.Forbidden:
                continue
        await self._audit(ctx, "unlock")
        await ctx.send(embed=embeds.success("🔓 The server has been unlocked."))

    @owner.command(name="slowmodeall", description="Set slowmode across every text channel.")
    @app_commands.describe(seconds="Slowmode delay in seconds (0 to disable)")
    @bot_owner_only()
    @commands.guild_only()
    async def owner_slowmodeall(self, ctx: commands.Context, seconds: app_commands.Range[int, 0, 21600]):
        await ctx.defer() if ctx.interaction else None
        for channel in ctx.guild.text_channels:
            try:
                await channel.edit(slowmode_delay=seconds)
            except discord.Forbidden:
                continue
        await self._audit(ctx, "slowmodeall", f"{seconds}s")
        await ctx.send(embed=embeds.success(f"🐌 Slowmode set to **{seconds}s** across all text channels."))

    @owner.command(name="emergency", description="Activate emergency lockdown + antinuke protection.")
    @bot_owner_only()
    @commands.guild_only()
    async def owner_emergency(self, ctx: commands.Context):
        await ctx.defer() if ctx.interaction else None
        for channel in ctx.guild.text_channels:
            try:
                overwrite = channel.overwrites_for(ctx.guild.default_role)
                overwrite.send_messages = False
                await channel.set_permissions(ctx.guild.default_role, overwrite=overwrite)
            except discord.Forbidden:
                continue
        await self.bot.db.execute(
            "INSERT INTO antinuke_settings (guild_id, enabled, strict_mode, lockdown, panic_mode) "
            "VALUES (?, 1, 1, 1, 1) ON CONFLICT(guild_id) DO UPDATE SET "
            "enabled = 1, strict_mode = 1, lockdown = 1, panic_mode = 1",
            (ctx.guild.id,),
        )
        await self._audit(ctx, "emergency")
        embed = embeds.error(
            "Emergency protection activated:\n"
            "• 🔒 All text channels locked\n"
            "• ⚡ Antinuke enabled (strict + lockdown)\n"
            "• 📜 Detailed security logging started\n"
            "• 🔔 Owners alerted",
            title="🚨 EMERGENCY MODE",
        )
        await ctx.send(embed=embed)

    @owner.command(name="permissions", description="Show the bot's permissions in this server.")
    @bot_owner_only()
    @commands.guild_only()
    async def owner_permissions(self, ctx: commands.Context):
        perms = [name.replace("_", " ").title() for name, val in ctx.guild.me.guild_permissions if val]
        embed = embeds.plain(title=f"{self.bot.user.name}'s Permissions", description=", ".join(perms) or "None")
        await ctx.send(embed=embed)

    @owner.command(name="audit", description="Show sensitive owner actions taken in this server.")
    @bot_owner_only()
    @commands.guild_only()
    async def owner_audit(self, ctx: commands.Context):
        rows = await self.bot.db.fetchall(
            "SELECT * FROM owner_audit WHERE guild_id = ? ORDER BY id DESC LIMIT 15", (ctx.guild.id,)
        )
        if not rows:
            return await ctx.send(embed=embeds.info("No owner actions logged yet."))
        lines = []
        for row in rows:
            when = datetime.fromtimestamp(row["created_at"], tz=timezone.utc)
            lines.append(f"<t:{int(when.timestamp())}:R> <@{row['actor_id']}> — **{row['action']}** {row['detail']}")
        await ctx.send(embed=embeds.plain(title="👑 Owner Audit Log", description="\n".join(lines)))

    # ============================================================
    #  🚀  noprefix  — commands can be run with no prefix at all
    # ============================================================
    @commands.hybrid_group(
        name="noprefix",
        description="Manage who can run commands with no prefix at all.",
        invoke_without_command=True,
    )
    async def noprefix(self, ctx: commands.Context):
        owner_rows = await self.bot.db.fetchall("SELECT user_id FROM bot_owners")
        np_rows = await self.bot.db.fetchall("SELECT user_id, added_by, added_at FROM noprefix_users ORDER BY added_at ASC")

        embed = embeds.plain(title="🚀 No-Prefix Access")
        embed.description = (
            "Users below can run any command by typing it directly — no `!` needed.\n"
            "Bot owners always have this automatically."
        )
        main = self.bot.get_user(config.MAIN_OWNER_ID)
        always_on = [f"👑 {(main.mention if main else f'`{config.MAIN_OWNER_ID}`')}  *(Main Owner)*"]
        always_on += [f"⭐ <@{r['user_id']}>  *(Owner)*" for r in owner_rows]
        embed.add_field(name="Always Enabled", value="\n".join(always_on), inline=False)

        if np_rows:
            lines = [f"• <@{r['user_id']}>" for r in np_rows]
            embed.add_field(name=f"Granted Manually ({len(np_rows)})", value="\n".join(lines), inline=False)
        else:
            embed.add_field(name="Granted Manually (0)", value="*None yet — use `noprefix add @user`.*", inline=False)

        await ctx.send(embed=embed)

    @noprefix.command(name="add", description="Let a user run commands with no prefix.")
    @app_commands.describe(user="The user to grant no-prefix access to")
    @bot_owner_only()
    async def noprefix_add(self, ctx: commands.Context, user: discord.User):
        if await is_bot_owner(self.bot, user.id):
            return await ctx.send(embed=embeds.info(f"{user.mention} is a bot owner and already has no-prefix access."))
        await self.bot.db.execute(
            "INSERT OR IGNORE INTO noprefix_users (user_id, added_by, added_at) VALUES (?, ?, ?)",
            (user.id, ctx.author.id, int(datetime.now(timezone.utc).timestamp())),
        )
        await self._audit(ctx, "noprefix_add", str(user.id))
        await ctx.send(embed=embeds.success(f"🚀 {user.mention} can now run commands with **no prefix**."))

    @noprefix.command(name="remove", description="Revoke a user's no-prefix access.")
    @app_commands.describe(user="The user to revoke no-prefix access from")
    @bot_owner_only()
    async def noprefix_remove(self, ctx: commands.Context, user: discord.User):
        await self.bot.db.execute("DELETE FROM noprefix_users WHERE user_id = ?", (user.id,))
        await self._audit(ctx, "noprefix_remove", str(user.id))
        await ctx.send(embed=embeds.success(f"Revoked no-prefix access from {user.mention}."))

    @noprefix.command(name="list", description="List everyone with no-prefix access.")
    async def noprefix_list(self, ctx: commands.Context):
        await self.noprefix(ctx)


async def setup(bot: commands.Bot):
    await bot.add_cog(Owner(bot))
