"""
utils/embeds.py — Every embed Kavya sends goes through here.
Keeping ONE place that builds embeds is what gives the whole bot a
consistent, professional look instead of every cog rolling its own style.
"""
from __future__ import annotations
import discord
from datetime import datetime, timezone
import config

# Set at runtime (main.py on_ready) once the bot's own avatar URL is known,
# so every embed carries a small branded header + footer icon — the same
# trick bots like Wick use to make every response instantly recognizable.
_BOT_ICON: str | None = None


def set_bot_icon(url: str) -> None:
    global _BOT_ICON
    _BOT_ICON = url


def _base(color: int, title: str | None, description: str | None) -> discord.Embed:
    embed = discord.Embed(
        title=title,
        description=description,
        color=color,
        timestamp=datetime.now(timezone.utc),
    )
    embed.set_author(name=config.BOT_NAME, icon_url=_BOT_ICON or config.FOOTER_ICON)
    embed.set_footer(text=config.FOOTER_TEXT, icon_url=_BOT_ICON or config.FOOTER_ICON)
    return embed


def success(description: str, title: str = "Success") -> discord.Embed:
    return _base(config.COLOR_SUCCESS, f"✅ {title}", description)


def error(description: str, title: str = "Error") -> discord.Embed:
    return _base(config.COLOR_ERROR, f"❌ {title}", description)


def warning(description: str, title: str = "Warning") -> discord.Embed:
    return _base(config.COLOR_WARNING, f"⚠️ {title}", description)


def info(description: str, title: str = "Info") -> discord.Embed:
    return _base(config.COLOR_INFO, f"ℹ️ {title}", description)


def plain(title: str | None = None, description: str | None = None,
          color: int = config.COLOR_PRIMARY) -> discord.Embed:
    """A blank branded embed for cogs that need full control over fields."""
    return _base(color, title, description)


def paginated_footer(embed: discord.Embed, page: int, total_pages: int) -> discord.Embed:
    embed.set_footer(text=f"{config.FOOTER_TEXT} • Page {page}/{total_pages}",
                      icon_url=config.FOOTER_ICON)
    return embed
