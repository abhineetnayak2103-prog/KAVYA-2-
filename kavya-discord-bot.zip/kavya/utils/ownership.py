"""
utils/ownership.py — the permanent Main Owner + secondary bot-owner system,
and the no-prefix allow-list. All bot-wide (not per-guild), like Wick's
owner system: one hard-coded Main Owner that can never be removed, plus
Main-Owner-managed secondary owners.
"""
from __future__ import annotations
from discord.ext import commands
import config


async def is_main_owner(user_id: int) -> bool:
    return user_id == config.MAIN_OWNER_ID


async def is_bot_owner(bot: commands.Bot, user_id: int) -> bool:
    if user_id == config.MAIN_OWNER_ID:
        return True
    row = await bot.db.fetchone("SELECT 1 FROM bot_owners WHERE user_id = ?", (user_id,))
    return bool(row)


async def is_noprefix_user(bot: commands.Bot, user_id: int) -> bool:
    if await is_bot_owner(bot, user_id):
        return True
    row = await bot.db.fetchone("SELECT 1 FROM noprefix_users WHERE user_id = ?", (user_id,))
    return bool(row)


def main_owner_only():
    """Only the permanent Main Owner may use this command."""
    async def predicate(ctx: commands.Context) -> bool:
        if ctx.author.id == config.MAIN_OWNER_ID:
            return True
        raise commands.CheckFailure("This command is restricted to the Main Owner.")
    return commands.check(predicate)


def bot_owner_only():
    """The Main Owner or any secondary bot owner may use this command."""
    async def predicate(ctx: commands.Context) -> bool:
        if await is_bot_owner(ctx.bot, ctx.author.id):
            return True
        raise commands.CheckFailure("This command is restricted to bot owners.")
    return commands.check(predicate)
